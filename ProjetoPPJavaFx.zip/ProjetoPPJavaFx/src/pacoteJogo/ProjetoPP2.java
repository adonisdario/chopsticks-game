package pacoteJogo;

import java.util.Scanner;

/**
 *
 * @author Adônis Dário
 */
public class ProjetoPP2 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int resp, rodada = 0, resp2 = 1, r;
        String nome1, nome2;
        Maos maos1, maos2, primeiro = new Maos(), aux;
        Fila fila = new Fila();
        Jogo jogo = new Jogo();
        ListaRanking lr = new ListaRanking();

        lr.carregarListaRanking("Highscores");

        do {
            menu();
            resp = in.nextInt();
            in.nextLine();
            switch (resp) {
                case 1:
                    do {
                        System.out.println("\n--- JOGAR ---");
                        System.out.println("\n1. Jogador | 2. Jogadores");
                        System.out.println("3. Sair");
                        System.out.print("Opção escolhida: ");
                        resp = in.nextInt();
                        in.nextLine();
                        switch (resp) {
                            case 1:
                                do {
                                    System.out.println("\n--- 1 JOGADOR ---");
                                    System.out.println("\n1. Fácil | 2. Difícil");
                                    System.out.println("3. Sair");
                                    System.out.print("Opção escolhida: ");
                                    r = in.nextInt();
                                    in.nextLine();
                                    switch (r) {
                                        case 1:
                                            System.out.println("\n---FÁCIL---");
                                            System.out.println("\nDigite o nome do Jogador (Colorido): ");
                                            nome1 = in.nextLine();
                                            if (nome1.equals("SAIR")) {
                                                break;
                                            }
                                            maos1 = new Maos();
                                            maos1.setNomeJogador(nome1);
                                            maos2 = new Maos();
                                            maos2.setNomeJogador("MaquinaFacil");
                                            do {
                                                System.out.println("\nQuem começa?");
                                                System.out.println(nome1 + ": 1 | MáquinaFacil: 2");
                                                resp = in.nextInt();
                                                in.nextLine();
                                                switch (resp) {
                                                    case 1:
                                                        jogo.jogador1Primeiro(maos1, maos2, fila);
                                                        primeiro = maos1;
                                                        break;
                                                    case 2:
                                                        jogo.jogador2Primeiro(maos1, maos2, fila);
                                                        primeiro = maos2;
                                                        break;
                                                    default:
                                                        System.out.println("Opção inválida.");
                                                        break;
                                                }
                                            } while (resp != 1 && resp != 2);

                                            resp2 = 1;
                                            while (resp2 != 0) {
                                                rodada++; //Contador de rodadas
                                                if (rodada == 1) {
                                                    if (primeiro.equals(maos1)) {
                                                        System.out.println(maos1.getNomeJogador() + " começa!");
                                                    } else {
                                                        System.out.println("Máquina começa!");
                                                    }
                                                }
                                                System.out.println("\nRODADA " + rodada);
                                                System.out.println("\nMáquinaFacil | Pontuação: " + maos2.getPontos());
                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());

                                                if (fila.head().getEsq() == 5) { //Mão Esquerda do Jogador possui 5 pontos
                                                    System.out.println("\n" + fila.head().getNomeJogador() + " Perdeu a sua Mão Esquerda!");
                                                    fila.head().setEsq(0);
                                                    System.out.println("\nMáquinaFacil | Pontuação: " + maos2.getPontos());
                                                    System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                    System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                    System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                                }
                                                if (fila.head().getDir() == 5) { //Mão Direita do Jogador 1 possui 5 pontos
                                                    System.out.println("\n" + fila.head().getNomeJogador() + " Perdeu a sua Mão Direita!");
                                                    fila.head().setDir(0);
                                                    System.out.println("\nMáquinaFacil | Pontuação: " + maos2.getPontos());
                                                    System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                    System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                    System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                                }

                                                if (fila.head().getDir() + fila.head().getEsq() == 0) { // Alguém não possui mais mãos
                                                    aux = fila.head();
                                                    if (aux.equals(maos1)) { // Jogador 1 PERDEU
                                                        maos1.setDerrotas(maos1.getDerrotas() + 1);
                                                        System.out.println("\n" + fila.dequeue().getNomeJogador()
                                                                + " não possui mãos em jogo!");
                                                        maos2 = fila.head();
                                                        maos2.setVitorias(maos2.getVitorias() + 1);
                                                        maos2.setPontos(fila.head().getPontos() + rodada);
                                                        System.out.println(fila.dequeue().getNomeJogador() + " é o Vencedor!\n");
                                                        System.out.println("PONTUAÇÃO FINAL: \n");
                                                        System.out.println("VENCEDOR: | " + maos2.getPontos() + " pts | " + maos2.getNomeJogador());
                                                        System.out.println("perdedor: | " + maos1.getPontos() + " pts | " + maos1.getNomeJogador());
                                                        resp2 = 0;
                                                        lr.cadastrarRanking(maos1.getNomeJogador(), "Facil", maos1.getPontos(), maos1.getVitorias(), maos1.getDerrotas());
                                                    } else { // Jogador 2 PERDEU
                                                        System.out.println("\n" + fila.dequeue().getNomeJogador()
                                                                + " não possui mãos em jogo!");
                                                        maos1 = fila.head();
                                                        maos1.setVitorias(maos1.getVitorias() + 1);
                                                        maos1.setPontos(fila.head().getPontos() + rodada);
                                                        System.out.println(fila.dequeue().getNomeJogador() + " é o Vencedor!\n");
                                                        System.out.println("PONTUAÇÃO FINAL: \n");
                                                        System.out.println("VENCEDOR: | " + maos1.getPontos() + " pts | " + maos1.getNomeJogador());
                                                        System.out.println("perdedor: | " + maos2.getPontos() + " pts | " + maos2.getNomeJogador());
                                                        do {
                                                            System.out.println("Deseja jogar novamente? Sim(1), Não(0)");
                                                            resp2 = in.nextInt();
                                                            in.nextLine();
                                                        } while (resp2 != 1 && resp2 != 0);
                                                        if (resp2 == 0) {
                                                            lr.cadastrarRanking(maos1.getNomeJogador(), "Facil", maos1.getPontos(), maos1.getVitorias(), maos1.getDerrotas());
                                                            break;
                                                        } else {
                                                            rodada = 1;
                                                            maos1.setEsq(1);
                                                            maos1.setDir(1);
                                                            maos2.setEsq(1);
                                                            maos2.setDir(1);
                                                            if (primeiro.equals(maos1)) { //muda a ordem
                                                                jogo.jogador2Primeiro(maos1, maos2, fila);
                                                                primeiro = maos2;
                                                                System.out.println(maos2.getNomeJogador() + " começa!");
                                                                System.out.println("\nRODADA " + rodada);
                                                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                                            } else {
                                                                jogo.jogador1Primeiro(maos1, maos2, fila);
                                                                primeiro = maos1;
                                                                System.out.println(nome1 + " começa!");
                                                                System.out.println("\nRODADA " + rodada);
                                                                System.out.println("\nMáquina | Pontuação: " + maos2.getPontos());
                                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                                System.out.println(nome1 + " | Pontuação: " + maos1.getPontos());
                                                            }
                                                        }
                                                    }
                                                }
                                                if (resp2 != 0) {
                                                    System.out.println("\nVez de: " + fila.head().getNomeJogador());
                                                    if ((fila.head().getEsq() + fila.head().getDir()) % 2 == 0
                                                            && (fila.head().getEsq() != fila.head().getDir())) { //Jogador pode dividir pontos
                                                        jogo.jogadorPodeDividir(fila, maos1, maos2);
                                                    } else { //Jogador Não Pode dividir pontos
                                                        jogo.jogadorNaoPodeDividir(fila, maos1, maos2);
                                                    }
                                                }
                                            }
                                            break;
                                        case 2:
                                            System.out.println("\n--- DIFÍCIL ---");
                                            System.out.println("\nDigite o nome do Jogador (Colorido): ");
                                            nome1 = in.nextLine();
                                            if (nome1.equals("SAIR")) {
                                                break;
                                            }
                                            maos1 = new Maos();
                                            maos1.setNomeJogador(nome1);
                                            maos2 = new Maos();
                                            maos2.setNomeJogador("MaquinaDificil");
                                            do {
                                                System.out.println("\nQuem começa?");
                                                System.out.println(nome1 + ": 1 | MáquinaDificil: 2");
                                                resp = in.nextInt();
                                                in.nextLine();
                                                switch (resp) {
                                                    case 1:
                                                        jogo.jogador1Primeiro(maos1, maos2, fila);
                                                        primeiro = maos1;
                                                        break;
                                                    case 2:
                                                        jogo.jogador2Primeiro(maos1, maos2, fila);
                                                        primeiro = maos2;
                                                        break;
                                                    default:
                                                        System.out.println("Opção inválida.");
                                                        break;
                                                }
                                            } while (resp != 1 && resp != 2);

                                            resp2 = 1;
                                            while (resp2 != 0) {
                                                rodada++; //Contador de rodadas
                                                if (rodada == 1) {
                                                    if (primeiro.equals(maos1)) {
                                                        System.out.println(maos1.getNomeJogador() + " começa!");
                                                    } else {
                                                        System.out.println("MáquinaDificil começa!");
                                                    }
                                                }
                                                System.out.println("\nRODADA " + rodada);
                                                System.out.println("\nMáquinaDificil | Pontuação: " + maos2.getPontos());
                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());

                                                if (fila.head().getEsq() == 5) { //Mão Esquerda do Jogador possui 5 pontos
                                                    System.out.println("\n" + fila.head().getNomeJogador() + " Perdeu a sua Mão Esquerda!");
                                                    fila.head().setEsq(0);
                                                    System.out.println("\nMáquinaDificil | Pontuação: " + maos2.getPontos());
                                                    System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                    System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                    System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                                }
                                                if (fila.head().getDir() == 5) { //Mão Direita do Jogador 1 possui 5 pontos
                                                    System.out.println("\n" + fila.head().getNomeJogador() + " Perdeu a sua Mão Direita!");
                                                    fila.head().setDir(0);
                                                    System.out.println("\nMáquinaDificil | Pontuação: " + maos2.getPontos());
                                                    System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                    System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                    System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                                }

                                                if (fila.head().getDir() + fila.head().getEsq() == 0) { // Alguém não possui mais mãos
                                                    aux = fila.head();
                                                    if (aux.equals(maos1)) { // Jogador 1 PERDEU
                                                        maos1.setDerrotas(maos1.getDerrotas() + 1);
                                                        System.out.println("\n" + fila.dequeue().getNomeJogador()
                                                                + " não possui mãos em jogo!");
                                                        maos2 = fila.head();
                                                        maos2.setVitorias(maos2.getVitorias() + 1);
                                                        maos2.setPontos(fila.head().getPontos() + rodada);
                                                        System.out.println(fila.dequeue().getNomeJogador() + " é o Vencedor!\n");
                                                        System.out.println("PONTUAÇÃO FINAL: \n");
                                                        System.out.println("VENCEDOR: | " + maos2.getPontos() + " pts | " + maos2.getNomeJogador());
                                                        System.out.println("perdedor: | " + maos1.getPontos() + " pts | " + maos1.getNomeJogador());
                                                        resp2 = 0;
                                                        lr.cadastrarRanking(maos1.getNomeJogador(), "Dificil", maos1.getPontos(), maos1.getVitorias(), maos1.getDerrotas());
                                                    } else { // Jogador 2 PERDEU
                                                        System.out.println("\n" + fila.dequeue().getNomeJogador()
                                                                + " não possui mãos em jogo!");
                                                        maos1 = fila.head();
                                                        maos1.setVitorias(maos1.getVitorias() + 1);
                                                        maos1.setPontos(fila.head().getPontos() + rodada);
                                                        System.out.println(fila.dequeue().getNomeJogador() + " é o Vencedor!\n");
                                                        System.out.println("PONTUAÇÃO FINAL: \n");
                                                        System.out.println("VENCEDOR: | " + maos1.getPontos() + " pts | " + maos1.getNomeJogador());
                                                        System.out.println("perdedor: | " + maos2.getPontos() + " pts | " + maos2.getNomeJogador());
                                                        do {
                                                            System.out.println("Deseja jogar novamente? Sim(1), Não(0)");
                                                            resp2 = in.nextInt();
                                                            in.nextLine();
                                                        } while (resp2 != 1 && resp2 != 0);
                                                        if (resp2 == 0) {
                                                            lr.cadastrarRanking(maos1.getNomeJogador(), "Dificil", maos1.getPontos(), maos1.getVitorias(), maos1.getDerrotas());
                                                            break;
                                                        } else {
                                                            rodada = 1;
                                                            maos1.setEsq(1);
                                                            maos1.setDir(1);
                                                            maos2.setEsq(1);
                                                            maos2.setDir(1);
                                                            if (primeiro.equals(maos1)) { //muda a ordem
                                                                jogo.jogador2Primeiro(maos1, maos2, fila);
                                                                primeiro = maos2;
                                                                System.out.println(maos2.getNomeJogador() + " começa!");
                                                                System.out.println("\nRODADA " + rodada);
                                                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                                            } else {
                                                                jogo.jogador1Primeiro(maos1, maos2, fila);
                                                                primeiro = maos1;
                                                                System.out.println(nome1 + " começa!");
                                                                System.out.println("\nRODADA " + rodada);
                                                                System.out.println("\nMáquinaDificil | Pontuação: " + maos2.getPontos());
                                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                                System.out.println(nome1 + " | Pontuação: " + maos1.getPontos());
                                                            }
                                                        }
                                                    }
                                                }
                                                if (resp2 != 0) {
                                                    System.out.println("\nVez de: " + fila.head().getNomeJogador());
                                                    if ((fila.head().getEsq() + fila.head().getDir()) % 2 == 0
                                                            && (fila.head().getEsq() != fila.head().getDir())) { //Jogador pode dividir pontos
                                                        jogo.jogadorPodeDividir(fila, maos1, maos2);
                                                    } else { //Jogador Não Pode dividir pontos
                                                        jogo.jogadorNaoPodeDividir(fila, maos1, maos2);
                                                    }
                                                }
                                            }
                                            break;
                                        case 3:
                                            break;
                                        default:
                                            System.out.println("Digite novamente.");
                                            break;
                                    }
                                } while (r != 3);
                                break;
                            case 2:
                                System.out.println("\n--- MULTIPLAYER ---");
                                System.out.println("\nDigite o nome do Jogador 1 (Colorido): ");
                                nome1 = in.nextLine();
                                if (nome1.equals("SAIR")) {
                                    break;
                                }
                                maos1 = new Maos();
                                maos1.setNomeJogador(nome1);
                                System.out.println("Digite o nome do Jogador 2 (Preto e Branco): ");
                                nome2 = in.nextLine();
                                if (nome2.equals("SAIR")) {
                                    break;
                                }
                                maos2 = new Maos();
                                maos2.setNomeJogador(nome2);

                                do {
                                    System.out.println("\nQuem começa?");
                                    System.out.println(nome1 + ": 1 | " + nome2 + ": 2");
                                    resp = in.nextInt();
                                    in.nextLine();
                                    switch (resp) {
                                        case 1:
                                            jogo.jogador1Primeiro(maos1, maos2, fila);
                                            primeiro = maos1;
                                            break;
                                        case 2:
                                            jogo.jogador2Primeiro(maos1, maos2, fila);
                                            primeiro = maos2;
                                            break;
                                        default:
                                            System.out.println("Opção inválida.");
                                            break;
                                    }
                                } while (resp != 1 && resp != 2);

                                do { //Começo de Jogo
                                    rodada++; //Contador de rodadas
                                    if (rodada == 1) {
                                        if (primeiro.equals(maos1)) {
                                            System.out.println(nome1 + " começa!");
                                        } else {
                                            System.out.println(nome2 + " começa!");
                                        }
                                    }
                                    System.out.println("\nRODADA " + rodada);
                                    System.out.println("\n" + nome2 + " | Pontuação: " + maos2.getPontos());
                                    System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                    System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                    System.out.println(nome1 + " | Pontuação: " + maos1.getPontos());

                                    if (fila.head().getEsq() == 5) { //Mão Esquerda do Jogador possui 5 pontos
                                        System.out.println("\n" + fila.head().getNomeJogador() + " Perdeu a sua Mão Esquerda!");
                                        fila.head().setEsq(0);
                                        System.out.println("\n" + nome2 + " | Pontuação: " + maos2.getPontos());
                                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                        System.out.println(nome1 + " | Pontuação: " + maos1.getPontos());
                                    }
                                    if (fila.head().getDir() == 5) { //Mão Direita do Jogador 1 possui 5 pontos
                                        System.out.println("\n" + fila.head().getNomeJogador() + " Perdeu a sua Mão Direita!");
                                        fila.head().setDir(0);
                                        System.out.println("\n" + nome2 + " | Pontuação: " + maos2.getPontos());
                                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                        System.out.println(nome1 + " | Pontuação: " + maos1.getPontos());
                                    }

                                    if (fila.head().getDir() + fila.head().getEsq() == 0) { // Alguém não possui mais mãos
                                        aux = fila.head();
                                        if (aux.equals(maos1)) { // Jogador 1 PERDEU
                                            maos1.setDerrotas(maos1.getDerrotas() + 1);
                                            System.out.println("\n" + fila.dequeue().getNomeJogador()
                                                    + " não possui mãos em jogo!");
                                            maos2 = fila.head();
                                            maos2.setVitorias(maos2.getVitorias() + 1);
                                            maos2.setPontos(fila.head().getPontos() + rodada);
                                            System.out.println(fila.dequeue().getNomeJogador() + " é o Vencedor!\n");
                                            System.out.println("PONTUAÇÃO FINAL: \n");
                                            System.out.println("VENCEDOR: | " + maos2.getPontos() + " pts | " + maos2.getNomeJogador());
                                            System.out.println("perdedor: | " + maos1.getPontos() + " pts | " + maos1.getNomeJogador());
                                        } else { // Jogador 2 PERDEU
                                            maos2.setDerrotas(maos2.getDerrotas() + 1);
                                            System.out.println("\n" + fila.dequeue().getNomeJogador()
                                                    + " não possui mãos em jogo!");
                                            maos1 = fila.head();
                                            maos1.setVitorias(maos1.getVitorias() + 1);
                                            maos1.setPontos(fila.head().getPontos() + rodada);
                                            System.out.println(fila.dequeue().getNomeJogador() + " é o Vencedor!\n");
                                            System.out.println("PONTUAÇÃO FINAL: \n");
                                            System.out.println("VENCEDOR: | " + maos1.getPontos() + " pts | " + maos1.getNomeJogador());
                                            System.out.println("perdedor: | " + maos2.getPontos() + " pts | " + maos2.getNomeJogador());
                                        }

                                        do {
                                            System.out.println("Deseja jogar novamente? Sim(1), Não(0)");
                                            resp2 = in.nextInt();
                                            in.nextLine();
                                        } while (resp2 != 1 && resp2 != 0);
                                        if (resp2 == 0) {
                                            lr.cadastrarRanking(maos1.getNomeJogador(), "Multiplayer", maos1.getPontos(), maos1.getVitorias(), maos1.getDerrotas());
                                            lr.cadastrarRanking(maos2.getNomeJogador(), "Multiplayer", maos2.getPontos(), maos2.getVitorias(), maos2.getDerrotas());
                                        } else {
                                            rodada = 1;
                                            maos1.setEsq(1);
                                            maos1.setDir(1);
                                            maos2.setEsq(1);
                                            maos2.setDir(1);
                                            if (primeiro.equals(maos1)) { //muda a ordem
                                                jogo.jogador2Primeiro(maos1, maos2, fila);
                                                primeiro = maos2;
                                                System.out.println(maos2.getNomeJogador() + " começa!");
                                                System.out.println("\nRODADA " + rodada);
                                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                            } else {
                                                jogo.jogador1Primeiro(maos1, maos2, fila);
                                                primeiro = maos1;
                                                System.out.println(maos1.getNomeJogador() + " começa!");
                                                System.out.println("\nRODADA " + rodada);
                                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                                            }
                                        }
                                    }
                                    if (resp2 == 1) {
                                        System.out.println("\nVez de: " + fila.head().getNomeJogador());
                                        if ((fila.head().getEsq() + fila.head().getDir()) % 2 == 0
                                                && (fila.head().getEsq() != fila.head().getDir())) { //Jogador pode dividir pontos
                                            jogo.jogadorPodeDividir(fila, maos1, maos2);
                                        } else { //Jogador Não Pode dividir pontos
                                            jogo.jogadorNaoPodeDividir(fila, maos1, maos2);
                                        }
                                    }
                                } while (resp2 != 0);
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opção inválida.");
                        }
                    } while (resp != 3);
                    resp = 0;
                    break;
                case 2:

                    break;
                case 3: //Ranking
                    do {
                        System.out.println("\n--- RANKING ---");
                        System.out.println("\n1. Jogador | 2. Jogadores\n3.Sair");
                        r = in.nextInt();
                        in.nextLine();
                        switch (r) {
                            case 1:
                                do {
                                    System.out.println("\n--- 1 JOGADOR ---");
                                    System.out.println("\n1. Fácil | 2. Difícil\n3.Sair");
                                    resp = in.nextInt();
                                    in.nextLine();
                                    switch (resp) {
                                        case 1:
                                            lr.exibirFacil();
                                            break;
                                        case 2:
                                            lr.exibirDificil();
                                            break;
                                        case 3:
                                            break;
                                    }
                                } while (resp != 3);
                                resp = 0;
                                break;
                            case 2:
                                lr.exibirMultiplayer();
                                break;
                            case 3:
                                break;
                        }
                    } while (r != 3);
                    break;
                case 4:
                    break;
            }
        } while (resp != 4);

        lr.gravarListaRanking("Highscores");
    }

    public static void menu() {
        System.out.println("====== CHOPSTICKS HAND GAME ======\n====== MATEMÉTICA DOS DEDOS ======\n");
        System.out.println("1.Jogar\n2.Regras\n3.Ranking de Pontuações\n4.Sair");
        System.out.print("Opção escolhida: ");
    }

}
