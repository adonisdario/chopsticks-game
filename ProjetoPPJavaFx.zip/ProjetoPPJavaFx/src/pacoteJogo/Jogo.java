package pacoteJogo;

import java.util.Random;
import java.util.Scanner;

public class Jogo {

    private static Scanner in = new Scanner(System.in);

    public void jogador1Primeiro(Maos maos1, Maos maos2, Fila fila) {
        fila.enqueue(maos1);
        fila.enqueue(maos2);
    }

    public void jogador2Primeiro(Maos maos1, Maos maos2, Fila fila) {
        fila.enqueue(maos2);
        fila.enqueue(maos1);
    }


    public void jogadorPodeDividir(Fila fila, Maos maos1, Maos maos2) {
        int podeD = 1;
        if (fila.head().getEsq() == 0) { //Jogador possui apenas Mão Direita
            jogadorPossuiMaoDir(fila, maos1, maos2, podeD);
        } else if (fila.head().getDir() == 0) { //Jogador possui apenas a mão Esquerda
            jogadorPossuiMaoEsq(fila, maos1, maos2, podeD);
        } else { //Jogador possui as duas Mãos
            jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
        }
    }

    public void jogadorNaoPodeDividir(Fila fila, Maos maos1, Maos maos2) {
        int podeD = 0;
        if (fila.head().getEsq() == 0) { //Jogador possui apenas a mão Direita
            jogadorPossuiMaoDir(fila, maos1, maos2, podeD);
        } else if (fila.head().getDir() == 0) { //Jogador possui apenas a mão Esquerda
            jogadorPossuiMaoEsq(fila, maos1, maos2, podeD);
        } else { //Jogador possui as duas mãos
            jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
        }
    }

    public void jogadorPossuiMaoEsq(Fila fila, Maos maos1, Maos maos2, int podeD) { //Colocar parâmetro para saber se pode ou não dividir
        int resp, mao = 1;
        Maos maos;
        Random rand = new Random();

        if (podeD == 1) { // Pode dividir
            if (fila.head().getNomeJogador().equals("MaquinaDificil")) { // É máquina
                maos = fila.dequeue();
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiMaoEsq(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiMaoDir(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                } else { //Oponente possui as duas mãos
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                }
            } else if (fila.head().getNomeJogador().equals("MaquinaFacil")) {
                maos = fila.dequeue();
                System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    mao = 11;
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    mao = 12;
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 11; // Fará Esq com Esq
                    } else {
                        mao = 12; // Fará Esq com Dir
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else {
                do {
                    System.out.println("1.Selecionar Mão Esquerda | 2.Dividir pontos");
                    resp = in.nextInt();
                    in.nextLine();
                    maos = fila.dequeue();
                    switch (resp) {
                        case 1: //Selecionou Mão Direita
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        case 2: //Escolheu dividir pontos
                            dividirPontos(maos);
                            fila.enqueue(maos);
                            fila.enqueue(fila.dequeue());
                            System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                            System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                            System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                            System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            podeD = 0;
                            jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                } while (resp != 1 && resp != 2);
            }
        } else { //Não pode dividir
            if (fila.head().getNomeJogador().equals("MaquinaDificil")) {
                maos = fila.dequeue();
                System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    mao = 11;
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    mao = 12;
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else {
                        mao = 10;
                        if (rand.nextInt(10) % 2 == 0) {
                            mao = mao + 1; //Fará Esq com Esq
                        } else {
                            mao = mao + 2; //Fará Esq com Dir
                        }
                        oponentePossuiDuasMaos(fila, maos, mao);
                    }
                }
            } else if (fila.head().getNomeJogador().equals("MaquinaFacil")) {
                maos = fila.dequeue();
                System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    mao = 11;
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    mao = 12;
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 11; // Fará Esq com Esq
                    } else {
                        mao = 12; // Fará Esq com Dir
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else {
                do {
                    System.out.println("1.Selecionar Mão Esquerda");
                    resp = in.nextInt();
                    in.nextLine();
                    switch (resp) {
                        case 1: //Selecionou Mão Direita
                            maos = fila.dequeue();
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                } while (resp != 1);
            }
        }
    }

    public void jogadorPossuiMaoDir(Fila fila, Maos maos1, Maos maos2, int podeD) {
        int resp, mao = 2; //Mao = 2 -> Dir
        Maos maos;
        Random rand = new Random();

        if (podeD == 1) {
            if (fila.head().getNomeJogador().equals("MaquinaDificil")) {
                maos = fila.dequeue();
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda                    
                    if (maos.getDir() + fila.head().getEsq() == 5) {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        oponentePossuiMaoEsq(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    if (maos.getDir() + fila.head().getDir() == 5) {
                        mao = 22;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        oponentePossuiMaoDir(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                } else { //Oponente possui as duas mãos
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                }
            } else if (fila.head().getNomeJogador().equals("MaquinaFacil")) {
                maos = fila.dequeue();
                System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    mao = 21;
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    mao = 22;
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 21; // Fará Dir com Esq
                    } else {
                        mao = 22; // Fará Dir com Dir
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else {
                do {
                    System.out.println("1.Selecionar Mão Direita | 2.Dividir pontos");
                    resp = in.nextInt();
                    in.nextLine();
                    maos = fila.dequeue();
                    switch (resp) {
                        case 1: //Selecionou Mão Direita
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        case 2: //Escolheu dividir pontos
                            dividirPontos(maos);
                            fila.enqueue(maos);
                            fila.enqueue(fila.dequeue());
                            System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                            System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                            System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                            System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            podeD = 0;
                            jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                } while (resp != 1 && resp != 2);
            }
        } else { // Não pode dividir
            if (fila.head().getNomeJogador().equals("MaquinaDificil")) {
                maos = fila.dequeue();
                System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    mao = 21;
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    mao = 22;
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (maos.getDir() + fila.head().getDir() == 5) {
                        mao = 22;
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getDir() + fila.head().getEsq() == 5) {
                        mao = 21;
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else {
                        mao = 20;
                        if (rand.nextInt(10) % 2 == 0) {
                            mao = mao + 1; //Fará Dir com Esq
                        } else {
                            mao = mao + 2; // Fará Dir com Dir
                        }
                        oponentePossuiDuasMaos(fila, maos, mao);
                    }
                }
            } else if (fila.head().getNomeJogador().equals("MaquinaFacil")) {
                maos = fila.dequeue();
                System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    mao = 21;
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    mao = 22;
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 21; // Fará Dir com Esq
                    } else {
                        mao = 22; // Fará Dir com Dir
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else {
                do {
                    System.out.println("1.Selecionar Mão Direita");
                    resp = in.nextInt();
                    in.nextLine();
                    switch (resp) {
                        case 1: //Selecionou Mão Direita
                            maos = fila.dequeue();
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                } while (resp != 1);
            }
        }
    }

    public void jogadorPossuiDuasMaos(Fila fila, Maos maos1, Maos maos2, int podeD) {
        int resp, mao; //Mao = 1 -> Esq , Mao = 2 -> Dir
        Maos maos;
        Random rand = new Random();
        if (podeD == 1) { //Pode dividir mãos
            if (fila.head().getNomeJogador().equals("MaquinaDificil")) {
                maos = fila.dequeue();
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiMaoEsq(fila, maos, mao);
                    } else if (maos.getDir() + fila.head().getEsq() == 5) {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        oponentePossuiMaoEsq(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiMaoDir(fila, maos, mao);
                    } else if (maos.getDir() + fila.head().getDir() == 5) {
                        mao = 22;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        oponentePossuiMaoDir(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                } else { //Oponente possui as duas mãos                    
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getDir() + fila.head().getDir() == 5) {
                        mao = 22;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else if (maos.getDir() + fila.head().getEsq() == 5) {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        oponentePossuiDuasMaos(fila, maos, mao);
                    } else {
                        dividirPontos(maos);
                        fila.enqueue(maos);
                        fila.enqueue(fila.dequeue());
                        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                        podeD = 0;
                        jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                    }
                }
            } else if (fila.head().getNomeJogador().equals("MaquinaFacil")) {
                maos = fila.dequeue();
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    }
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    }
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos                    
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 10;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else {
                        mao = 20;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    }
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = mao + 1;
                    } else {
                        mao = mao + 2;
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else {
                do {
                    System.out.println("1.Selecionar Mão Esquerda | 2.Selecionar Mão Direita | 3.Dividir Pontos");
                    resp = in.nextInt();
                    in.nextLine();
                    maos = fila.dequeue();
                    switch (resp) {
                        case 1: //Selecionou Mão Esquerda
                            mao = 1;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        case 2: //Selecionou Mão Direita
                            mao = 2;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        case 3: //Escolheu dividir pontos
                            dividirPontos(maos);
                            fila.enqueue(maos);
                            fila.enqueue(fila.dequeue());
                            System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                            System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                            System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                            System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            podeD = 0;
                            jogadorPossuiDuasMaos(fila, maos1, maos2, podeD);
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                } while (resp != 1 && resp != 2 && resp != 3);
            }
        } else { //Não pode dividir
            if (fila.head().getNomeJogador().equals("MaquinaDificil")) {
                maos = fila.dequeue();
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else if (maos.getDir() + fila.head().getEsq() == 5) {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    } else {
                        if (rand.nextInt(10) % 2 == 0) {
                            mao = 11;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        } else {
                            mao = 21;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        }
                    }
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else if (maos.getDir() + fila.head().getDir() == 5) {
                        mao = 22;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    } else {
                        if (rand.nextInt(10) % 2 == 0) {
                            mao = 12;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        } else {
                            mao = 22;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        }
                    }
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos
                    if (maos.getEsq() + fila.head().getDir() == 5) {
                        mao = 12;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else if (maos.getDir() + fila.head().getDir() == 5) {
                        mao = 22;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    } else if (maos.getEsq() + fila.head().getEsq() == 5) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else if (maos.getDir() + fila.head().getEsq() == 5) {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    } else {
                        if (rand.nextInt(10) % 2 == 0) {
                            mao = 10;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                        } else {
                            mao = 20;
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                        }
                        if (rand.nextInt(10) % 2 == 0) {
                            mao = mao + 1; //Somará com Esq
                        } else {
                            mao = mao + 2; //Somará com Dir
                        }
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else if (fila.head().getNomeJogador().equals("MaquinaFacil")) {
                maos = fila.dequeue();
                if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    }
                    oponentePossuiMaoEsq(fila, maos, mao);
                } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 11;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else {
                        mao = 21;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    }
                    oponentePossuiMaoDir(fila, maos, mao);
                } else { //Oponente possui as duas mãos                    
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = 10;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                    } else {
                        mao = 20;
                        System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                    }
                    if (rand.nextInt(10) % 2 == 0) {
                        mao = mao + 1;
                    } else {
                        mao = mao + 2;
                    }
                    oponentePossuiDuasMaos(fila, maos, mao);
                }
            } else {
                do {
                    System.out.println("1.Selecionar Mão Esquerda | 2.Selecionar Mão Direita");
                    resp = in.nextInt();
                    in.nextLine();
                    switch (resp) {
                        case 1: //Selecionou Mão Esquerda
                            mao = 1;
                            maos = fila.dequeue();
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Esquerda!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        case 2: //Selecionou Mão Direita
                            mao = 2;
                            maos = fila.dequeue();
                            System.out.println(maos.getNomeJogador() + " selecionou Mão Direita!");
                            if (fila.head().getDir() == 0) { //Oponente possui apenas mão esquerda
                                oponentePossuiMaoEsq(fila, maos, mao);
                            } else if (fila.head().getEsq() == 0) { //Oponente possui apenas mão direita
                                oponentePossuiMaoDir(fila, maos, mao);
                            } else { //Oponente possui as duas mãos
                                oponentePossuiDuasMaos(fila, maos, mao);
                            }
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }
                } while (resp != 1 && resp != 2);
            }
        }
    }

    public void oponentePossuiMaoEsq(Fila fila, Maos maos, int mao) {
        if (maos.getNomeJogador().contains("Maquina")) {
            if (mao == 11) {
                esqEsq(fila, maos);
            } else if (mao == 21) {
                dirEsq(fila, maos);
            }
        } else {
            int resp;
            do {
                System.out.println("1.Somar com Mão Esquerda do oponente");
                resp = in.nextInt();
                in.nextLine();
                if (resp == 1) {
                    if (mao == 1) {
                        esqEsq(fila, maos);
                    } else {
                        dirEsq(fila, maos);
                    }
                } else {
                    System.out.println("Digite novamente.");
                }
            } while (resp != 1);
        }

    }

    public void oponentePossuiMaoDir(Fila fila, Maos maos, int mao) {
        if (maos.getNomeJogador().contains("Maquina")) {
            if (mao == 12) {
                esqDir(fila, maos);
            } else if (mao == 22) {
                dirDir(fila, maos);
            }
        } else {
            int resp;
            do {
                System.out.println("1.Somar com Mão Direita do oponente");
                resp = in.nextInt();
                in.nextLine();
                if (resp == 1) {
                    if (mao == 1) {
                        esqDir(fila, maos);
                    } else {
                        dirDir(fila, maos);
                    }
                } else {
                    System.out.println("Digite Novamente");
                }
            } while (resp != 1);
        }
    }

    public void oponentePossuiDuasMaos(Fila fila, Maos maos, int mao) {
        if (maos.getNomeJogador().contains("Maquina")) {
            if (mao == 11) {
                esqEsq(fila, maos);
            } else if (mao == 12) {
                esqDir(fila, maos);
            } else if (mao == 21) {
                dirEsq(fila, maos);
            } else if (mao == 22) {
                dirDir(fila, maos);
            }
        } else {
            int resp;
            do {
                System.out.println("1.Somar com Mão Esquerda do oponente | 2.Somar com"
                        + " Mão Direita do Oponente");
                resp = in.nextInt();
                in.nextLine();
                switch (resp) {
                    case 1:
                        if (mao == 1) {
                            esqEsq(fila, maos);
                        } else { //Jogador fez Dir com Esq                        
                            dirEsq(fila, maos);
                        }
                        break;
                    case 2:
                        if (mao == 1) {
                            esqDir(fila, maos);
                        } else { //Jogador fez Dir com Dir
                            dirDir(fila, maos);
                        }
                        break;
                    default:
                        System.out.println("Digite novamente.");
                        break;
                }
            } while (resp != 1 && resp != 2);
        }
    }

    public void dividirPontos(Maos maos) {
        int soma;
        soma = maos.getEsq() + maos.getDir();
        maos.setPontos(maos.getPontos() + soma);
        soma = soma / 2;
        maos.setEsq(soma);
        maos.setDir(soma);
        System.out.println(maos.getNomeJogador() + " dividiu os pontos das Mãos!");
    }

    public void esqEsq(Fila fila, Maos maos) {
        System.out.println(maos.getNomeJogador()
                + " somou sua Mão Esquerda com Mão Esquerda do oponente!");
        if (maos.getEsq() + fila.head().getEsq() > 5) {
            System.out.println(maos.getEsq() + " + " + fila.head().getEsq() + " = " + (maos.getEsq() + fila.head().getEsq())
                    + " - 5 = " + (maos.getEsq() + fila.head().getEsq() - 5));
            fila.head().setEsq(maos.getEsq() + fila.head().getEsq() - 5);
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        } else {
            fila.head().setEsq(maos.getEsq() + fila.head().getEsq());
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        }

    }

    public void esqDir(Fila fila, Maos maos) {
        System.out.println(maos.getNomeJogador()
                + " somou sua Mão Esquerda com Mão Direita do oponente!");
        if (maos.getEsq() + fila.head().getDir() > 5) {
            System.out.println(maos.getEsq() + " + " + fila.head().getDir() + " = " + (maos.getEsq() + fila.head().getDir())
                    + " - 5 = " + (maos.getEsq() + fila.head().getDir() - 5));
            fila.head().setDir(maos.getEsq() + fila.head().getDir() - 5);
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        } else {
            fila.head().setDir(maos.getEsq() + fila.head().getDir());
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        }

    }

    public void dirEsq(Fila fila, Maos maos) {
        System.out.println(maos.getNomeJogador()
                + " somou sua Mão Direita com Mão Esquerda do oponente!");
        if (maos.getDir() + fila.head().getEsq() > 5) {
            System.out.println(maos.getDir() + " + " + fila.head().getEsq() + " = " + (maos.getDir() + fila.head().getEsq())
                    + " - 5 = " + (maos.getDir() + fila.head().getEsq() - 5));
            fila.head().setEsq(maos.getDir() + fila.head().getEsq() - 5);
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        } else {
            fila.head().setEsq(maos.getDir() + fila.head().getEsq());
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        }
    }

    public void dirDir(Fila fila, Maos maos) {
        System.out.println(maos.getNomeJogador()
                + " somou sua Mão Direita com Mão Direita do oponente!");
        if (maos.getDir() + fila.head().getDir() > 5) {
            System.out.println(maos.getDir() + " + " + fila.head().getDir() + " = " + (maos.getDir() + fila.head().getDir())
                    + " - 5 = " + (maos.getDir() + fila.head().getDir() - 5));
            fila.head().setDir(maos.getDir() + fila.head().getDir() - 5);
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        } else {
            fila.head().setDir(maos.getDir() + fila.head().getDir());
            maos.setPontos(maos.getPontos() + fila.head().getEsq() + fila.head().getDir());
            fila.enqueue(maos);
        }
    }

}
