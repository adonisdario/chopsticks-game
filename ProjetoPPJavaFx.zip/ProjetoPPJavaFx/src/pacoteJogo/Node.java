package pacoteJogo;

public class Node {

    private Maos data;
    private Node next;

    Node(Maos p) {
        data = p;
    }

    Maos getData() {
        return data;
    }

    void setData(Maos data) {
        this.data = data;
    }

    Node getNext() {
        return next;
    }

    void setNext(Node next) {
        this.next = next;
    }
}
