package pacoteJogo;

public class Fila {

    private Node inicio, fim;

    public boolean isEmpty() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isFull() {
        return false;
    }

    public Maos head() {
        return inicio.getData();
    }

    public void enqueue(Maos p) {
        Node novo = new Node(p);
        if (isEmpty() == true) {
            inicio = novo;
            fim = novo;
        } else {
            fim.setNext(novo);
            fim = novo;
        }
    }

    public Maos dequeue() {
        Node aux = inicio;
        inicio = inicio.getNext();
        if (inicio == null) {
            fim = null;
        }
        return aux.getData();
    }
}
