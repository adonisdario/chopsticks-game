package pacoteJogo;

public class ListaRanking {

    public NodeRanking first;
    private NodeRanking last;

    public boolean isFull(String categoria) {
        NodeRanking aux = first;
        int cont = 0;
        while (aux != null) {
            if (categoria.equals(aux.getData().getCategoria())) {
                cont++;
                if (cont == 5) {
                    return true;
                }
            }
        }
        return false;
    }

    public void cadastrarRanking(String nomeJogador, String categoria, int pontuacao, int vitorias, int derrotas) {
        NodeRanking aux, aux2, novo;
        Ranking ranking;
        if (first == null) {
            ranking = new Ranking(nomeJogador);
            ranking.setCategoria(categoria);
            ranking.setVitorias(vitorias);
            ranking.setDerrotas(derrotas);
            ranking.setMaxPont(pontuacao);
            novo = new NodeRanking(ranking);
            first = novo;
            last = novo;
            System.out.println("1a Pontuação gravada.");
        } else if (pontuacao >= first.getData().getMaxPont()) {
            if (isFull(categoria)) {
                removerUltimoRanking(categoria);
            }
            ranking = new Ranking(nomeJogador);
            ranking.setCategoria(categoria);
            ranking.setVitorias(vitorias);
            ranking.setDerrotas(derrotas);
            ranking.setMaxPont(pontuacao);
            novo = new NodeRanking(ranking);
            novo.setNext(first);
            first.setPrev(novo);
            first = novo;
            System.out.println("Pontuação gravada.");
        } else if (pontuacao <= last.getData().getMaxPont()) {
            if (isFull(categoria)) {
                removerUltimoRanking(categoria);
            }
            ranking = new Ranking(nomeJogador);
            ranking.setCategoria(categoria);
            ranking.setVitorias(vitorias);
            ranking.setDerrotas(derrotas);
            ranking.setMaxPont(pontuacao);
            novo = new NodeRanking(ranking);
            last.setNext(novo);
            novo.setPrev(last);
            last = novo;
            System.out.println("Pontuação gravada.");
        } else {
            aux = first.getNext();
            while (aux != null) {
                if (pontuacao <= aux.getData().getMaxPont()) {
                    if (isFull(categoria)) {
                        removerUltimoRanking(categoria);
                    }
                    ranking = new Ranking(nomeJogador);
                    ranking.setCategoria(categoria);
                    ranking.setVitorias(vitorias);
                    ranking.setDerrotas(derrotas);
                    ranking.setMaxPont(pontuacao);
                    novo = new NodeRanking(ranking);
                    aux2 = aux.getPrev();
                    novo.setPrev(aux2);
                    novo.setNext(aux);
                    aux2.setNext(novo);
                    aux.setPrev(novo);
                    System.out.println("Pontuação gravada.\n");
                    return;
                }
                aux = aux.getNext();
            }
        }
    }

    public void exibirFacil() {
        int cont = 1;
        NodeRanking aux = first;
        if (first == null) {
            System.out.println("Nenhuma pontuação registrada.");
            return;
        } else {
            System.out.println("\n++++++ FÁCIL ++++++");
            while (aux != null) {
                if (aux.getData().getCategoria().equals("Facil")) {
                    System.out.println(cont + "º: " + aux.getData());
                    cont++;
                    if (cont == 5) {
                        return;
                    }
                }
                aux = aux.getNext();
            }
        }
        if (cont == 0) {
            System.out.println("Nenhuma pontuação desta categoria registrada.");
        }
    }

    public void exibirDificil() {
        int cont = 1;
        NodeRanking aux = first;
        if (first == null) {
            System.out.println("Nenhuma pontuação registrada.");
            return;
        } else {
            System.out.println("\n++++++ DIFÍCIL ++++++");
            while (aux != null) {
                if (aux.getData().getCategoria().equals("Dificil")) {
                    System.out.println(cont + "º: " + aux.getData());
                    cont++;
                    if (cont == 5) {
                        return;
                    }
                }
                aux = aux.getNext();
            }
        }
        if (cont == 0) {
            System.out.println("Nenhuma pontuação desta categoria registrada.");
        }
    }

    public void exibirMultiplayer() {
        int cont = 1;
        NodeRanking aux = first;
        if (first == null) {
            System.out.println("Nenhuma pontuação registrada.");
            return;
        } else {
            System.out.println("\n++++++ MULTIPLAYER ++++++");
            while (aux != null) {
                if (aux.getData().getCategoria().equals("Multiplayer")) {
                    System.out.println(cont + "º: " + aux.getData());
                    cont++;
                    if (cont == 5) {
                        return;
                    }
                }
                aux = aux.getNext();
            }
        }
        if (cont == 0) {
            System.out.println("Nenhuma pontuação desta categoria registrada.");
        }
    }

    public void removerUltimoRanking(String categoria) { //Remove o cliente da lista.
        NodeRanking aux = first, aux2;
        int cont = 0;
        if (first == null) {
            System.out.println("Lista Vazia.");
            return;
        } else {
            while (aux != null) {
                if (categoria.equals(aux.getData().getCategoria())) {
                    cont++;
                    if (cont == 5) {
                        if (aux == last) {
                            last.setNext(null);
                            last = last.getPrev();
                        } else {
                            aux2 = aux.getPrev();
                            aux = aux.getNext();
                            aux2.setNext(aux);
                            aux.setPrev(aux2);
                        }
                        System.out.println("Ranking removido do cadastro.");
                        return;
                    }
                }
                aux = aux.getNext();
            }
        }
    }

    public void reinserirListaRanking(Ranking r) {
        NodeRanking novo = new NodeRanking(r);

        if (this.first == null) {
            this.first = novo;
            this.last = novo;
        } else {
            this.last.setNext(novo);
            novo.setPrev(this.last);
            this.last = novo;
        }
    } //OK

    public void gravarListaRanking(String nomeArq) { // Da lista para o arquivo
        NodeRanking aux = this.first;

        if (this.first == null) {
            ArquivoBinarioRanking arq = new ArquivoBinarioRanking();
            arq.openToWrite(nomeArq);
            arq.gravarRanking(null);
            arq.closeWriteFile();
        } else {
            ArquivoBinarioRanking arq = new ArquivoBinarioRanking();
            arq.openToWrite(nomeArq);
            while (aux != null) {
                arq.gravarRanking(aux.getData());
                aux = aux.getNext();
            }
            arq.closeWriteFile();
        }
    } //OK

    public void carregarListaRanking(String nomeArq) { // Do arquivo para a lista
        ArquivoBinarioRanking arq = new ArquivoBinarioRanking();
        Ranking r;

        boolean exists = arq.openToRead(nomeArq);
        if (exists == true) {
            r = arq.lerRanking();
            while (r != null) {
                this.reinserirListaRanking(r);
                r = arq.lerRanking();
            }
            arq.closeReadFile();
            System.out.println("Arquivo Ranking aberto.");
        } else {
            arq.openToWrite(nomeArq);
            arq.closeWriteFile();
            System.out.println("Arquivo Ranking criado.");
        }
    }
}
