package pacoteJogo;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Maos {

    private int esq = 1, dir = 1, pontos, vitorias, derrotas;
    private String nomeJogador;
    private ImageView maoEsq, maoDir;

    public Maos() {
        esq = 1;
        dir = 1;
        maoEsq = new ImageView(new Image("C:/Users/DELL/Pictures/Chapiuski.jpg"));
    }

    public ImageView getMaoEsq() {
        return maoEsq;
    }

    public void setMaoEsq(ImageView maoEsq) {
        this.maoEsq = maoEsq;
    }

    public ImageView getMaoDir() {
        return maoDir;
    }

    public void setMaoDir(ImageView maoDir) {
        this.maoDir = maoDir;
    }

    public int getEsq() {
        return esq;
    }

    public void setEsq(int esq) {
        this.esq = esq;
    }

    public int getDir() {
        return dir;
    }

    public void setDir(int dir) {
        this.dir = dir;
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getVitorias() {
        return vitorias;
    }

    public void setVitorias(int vitorias) {
        this.vitorias = vitorias;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

}
