package pacoteJogo;

public class NodeRanking {
    private Ranking data;
    private NodeRanking next, prev;

    public NodeRanking(Ranking data) {
        this.data = data;
    }

    public Ranking getData() {
        return data;
    }

    public void setData(Ranking data) {
        this.data = data;
    }

    public NodeRanking getNext() {
        return next;
    }

    public void setNext(NodeRanking next) {
        this.next = next;
    }

    public NodeRanking getPrev() {
        return prev;
    }

    public void setPrev(NodeRanking prev) {
        this.prev = prev;
    }
    
    
}
