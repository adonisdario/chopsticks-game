/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class FXMLRegrasController implements Initializable {

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button botaoParaSair;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        botaoParaSair.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Saindo das Regras. Voltando para o Menu.");
            MainRegras.stage.close();
            ProjetoPPJavaFx menu = new ProjetoPPJavaFx();
            try {
                menu.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

}
