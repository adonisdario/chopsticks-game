/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import pacoteJogo.ListaRanking;
import pacoteJogo.NodeRanking;
import pacoteJogo.Ranking;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class FXMLRankingController implements Initializable {

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button facil;

    @FXML
    private Button dificil;

    @FXML
    private Button multiplayer;

    @FXML
    private Button botaoParaSair;

    @FXML
    private ListView<Ranking> lvRanking;

    private ListaRanking lr;

    private ObservableList<Ranking> obsRanking;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        botaoParaSair.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Saindo do ranking. Voltando para o Menu.");
            MainRanking.stage.close();
            ProjetoPPJavaFx menu = new ProjetoPPJavaFx();
            try {
                menu.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        facil.setOnMouseClicked((MouseEvent e) -> {
            if (obsRanking != null) {
                obsRanking.removeAll();
            }
            System.out.println("Abrindo Ranking Fácil.");
            pegarRankingFacil();
        });
        dificil.setOnMouseClicked((MouseEvent e) -> {
            if (obsRanking != null) {
                obsRanking.removeAll();
            }
            System.out.println("Abrindo Ranking Difícil.");
            pegarRankingDificil();
        });
        multiplayer.setOnMouseClicked((MouseEvent e) -> {
            if (obsRanking != null) {
                obsRanking.removeAll();
            }
            System.out.println("Abrindo Ranking Multiplayer.");
            pegarRankingMultiplayer();
        });
    }

    public void pegarRankingFacil() {
        if (lr == null) {
            System.out.println("Ranking Vazio.");
            return;
        }
        NodeRanking aux = lr.first;
        while (aux != null) {
            if (aux.getData().getCategoria().equals("Facil")) {
                obsRanking.add(aux.getData());
            }
            aux = aux.getNext();
        }
        lvRanking.setItems(obsRanking);
    }

    public void pegarRankingDificil() {
        if (lr == null) {
            System.out.println("Ranking Vazio.");
            return;
        }
        NodeRanking aux = lr.first;
        while (aux != null) {
            if (aux.getData().getCategoria().equals("Dificil")) {
                obsRanking.add(aux.getData());
            }
            aux = aux.getNext();
        }
        lvRanking.setItems(obsRanking);
    }

    public void pegarRankingMultiplayer() {
        if (lr == null) {
            System.out.println("Ranking Vazio.");
            return;
        }
        NodeRanking aux = lr.first;
        while (aux != null) {
            if (aux.getData().getCategoria().equals("Multiplayer")) {
                obsRanking.add(aux.getData());
            }
            aux = aux.getNext();
        }
        lvRanking.setItems(obsRanking);
    }

}
