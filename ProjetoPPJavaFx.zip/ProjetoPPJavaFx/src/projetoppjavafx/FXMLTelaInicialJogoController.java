package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

public class FXMLTelaInicialJogoController implements Initializable {
    @FXML
    private AnchorPane telaMenu;

    @FXML
    private ImageView fundo1;

    @FXML
    private ImageView fundo2;

    @FXML
    private ImageView logoCatolica;

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button botaoMultiplayer;

    @FXML
    private Button botaoDificil;

    @FXML
    private Button botaoFacil;

    @FXML
    private Text autor;

    @FXML
    private Button botaoParaSair;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        botaoParaSair.setOnMouseClicked((MouseEvent e) -> { //Clicou no botão para sair
            System.out.println("Saindo do jogo.");
            ProjetoPPJavaFx.stage.close();
        });
    }    
    
}
