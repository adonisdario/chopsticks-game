/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author DELL
 */
public class FXMLMenuController implements Initializable {

       @FXML
    private AnchorPane telaMenu;

    @FXML
    private ImageView fundo1;

    @FXML
    private ImageView fundo2;

    @FXML
    private ImageView logoCatolica;

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button botaoSair;

    @FXML
    private Button botaoRanking;

    @FXML
    private Button botaoRegras;

    @FXML
    private Button botaoJogar;

    @FXML
    private Text autor;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        botaoJogar.setOnMouseClicked((MouseEvent e) -> { 
            System.out.println("Entrando na tela inicial jogo.");
            ProjetoPPJavaFx.stage.close();
            MainJogo menuJogo = new MainJogo();
            try {
                menuJogo.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });        
        botaoRanking.setOnMouseClicked((MouseEvent e) -> {
            System.out.println("Entrando no ranking");
            ProjetoPPJavaFx.stage.close();
            MainRanking menuRanking = new MainRanking();
            try {
                menuRanking.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        botaoRegras.setOnMouseClicked((MouseEvent e) -> { 
            System.out.println("Entrando nas regras");
            ProjetoPPJavaFx.stage.close();
            MainRegras menuRegras = new MainRegras();
            try {
                menuRegras.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        botaoSair.setOnMouseClicked((MouseEvent e) -> { //Clicou no botão para sair
            System.out.println("Saindo do jogo.");
            ProjetoPPJavaFx.stage.close();
        });
        
    }

}
